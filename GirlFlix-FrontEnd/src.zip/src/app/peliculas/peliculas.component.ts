import { Component } from '@angular/core';
import { Pelicula } from '../models/pelicula.model';
import { FavoritosComponent } from '../favoritos/favoritos.component'; 

@Component({
  selector: 'app-peliculas',
  templateUrl: './peliculas.component.html',
  styleUrls: ['./peliculas.component.css']
})
export class PeliculasComponent {
  peliculas: Pelicula[] = [
    {
      id: 1,
      titulo: "Taylor Swift: The Eras Tour",
      imagen: "assets/images/taylor.jpg",
      descripcion: "Un viaje a través de la carrera de Taylor Swift, desde sus inicios hasta su éxito actual.",
      favorito: false
    },
    {
      id: 2,
      titulo: "Blanca Nieves",
      imagen: "assets/images/blancaNieves.jpeg",
      descripcion: "La historia de Blanca Nieves, una princesa que se enfrenta a la malvada reina.",
      favorito: false
    }
  ];

  // Método para agregar una película a favoritos
  peliculasFavoritas: Pelicula[] = [];

  agregarAFavoritos(pelicula: Pelicula) {
    if (!this.peliculasFavoritas.includes(pelicula)) {
      this.peliculasFavoritas.push(pelicula);
    }
  }

  eliminarDeFavoritos(pelicula: Pelicula) {
    const index = this.peliculasFavoritas.indexOf(pelicula);
    if (index !== -1) {
      this.peliculasFavoritas.splice(index, 1);
    }
  }
}
